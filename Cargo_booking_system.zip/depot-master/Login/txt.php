<!DOCTYPE html>
<html>

<head>
	<title>Transaction</title>
</head>

<body>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "loginsystem");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		// Taking all 5 values from the form data(input)
		$Name = $_REQUEST['Name'];
		$Amount = $_REQUEST['Amount'];
		$Transaction_id = $_REQUEST['Transaction_id'];
		$Company = $_REQUEST['Company'];
		$Contact = $_REQUEST['Contact'];
		$location = $_REQUEST['location'];
		$Date = $_REQUEST['Date'];
		$id = $_REQUEST['id'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO transaction VALUES ('$Name','$Amount','$Transaction_id','$Company','$Contact','$location','$Date','$id')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully."
				. " Please browse your localhost php my admin"
				. " to view the updated data</h3>";

			echo nl2br("\n$Name\n $Amount\n "
				. "$Transaction_id\n $Company\n $Contact \n $location \n $Date \n  " );
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
