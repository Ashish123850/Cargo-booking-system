<?php 
$con=mysqli_connect("localhost","root","","loginsystem"); 
if(!$con) { die(" Connection Error "); } 
?>