<?php

$myemail = "mayurg78600@gmail.com";
$mypassword = "Mayur786@@";

?>
