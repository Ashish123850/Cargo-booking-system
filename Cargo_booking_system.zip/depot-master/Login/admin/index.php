<?php 
require_once("connection.php");
    $query = " select * from profile ";
    $result = mysqli_query($con,$query);
?> 
<html>
	
	<head>
	 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    

    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="../../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="../../css/aos.css">
<!-- MAIN CSS -->
    <link rel="stylesheet" href="../../css/style.css">

   
	</head>
	
	<style>
		body{
			padding-top:px;
			padding-left: px;
			padding-right: px;
			background-color:;
		}
		.f form{
			border-style : solid;
			border-radius: 75px 80px;
			padding-top: 80px;
			padding-bottom: 80px;
		}
		textarea {
			resize: none;
		}
		
		table{
			border-style : solid;
			
			
		}
		
		/* Dropdown Button */
.dropbtn {
  background-color: #3498DB;
  color: white;
  padding: 16px;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
  background-color: #2980B9;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 120px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd;}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}
		
	</style>
	<script>
	/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
	</script>
	
	<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
	
	 <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>


      
      <header class="site-navbar js-sticky-header site-navbar-target" role="banner">

        <div class="container">
          <div class="row align-items-center position-relative">


            <div class="site-logo">
			  <a href="index.html" class="text-black"><span class="text-primary"></a>
			  
            </div>

            <div class="col-9">
              <nav class="site-navigation text-right ml-auto " role="navigation">

                <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
                  <li><a href="userprofile.php" class="nav-link">User Profiles</a></li>
                  <li><a href="providerprofile.php" class="nav-link">Provider Profiles</a></li>
                  <li><a href="companies.php" class="nav-link">Companies</a></li>
                  <li><a href="transaction.php" class="nav-link">Transactions</a></li>
				  


                  <li>
                    <a href="order.php" class="nav-link">Orders Details</a>
                    
                  </li>
				  

                  <li><a<div class="dropdown">
  <button onclick="myFunction()" class="dropbtn">View More</button>
  <div id="myDropdown" class="dropdown-content">
    <a href="add_c.php">Add Company</a>
    <a href="quer.php">Query</a>
    
  </div>
</div></a></li>
                
                  <li><a href="#contact-section" class="nav-link"></a></li>
				
                  

  </ul>
  	       </nav>

            </div>
			<br><br>
			
			
			
			<table align="center" border="1px" style="width:600px; line-height:40px;"> 
	<tr> 
		<th colspan="4"><h2><center> Company Details </center></h2></th> 
		</tr> 
			  <th> Company Name</th> 
			  <th> Company address </th> 
			  <th> Company Email </th> 
			  <th> Company services </th> 
			  <th> Company Details </th> 
			  <th>Actions </th> 
			  
			  
		</tr> 
		
		<?php while($rows=mysqli_fetch_assoc($result)) 
		{ 
		?> 
		<tr> 
		<td><?php echo $rows['c_name']; ?></td> 
		<td><?php echo $rows['c_address']; ?></td> 
		<td><?php echo $rows['c_email']; ?></td> 
		<td><?php echo $rows['c_service']; ?></td> 
		<td><?php echo $rows['c_details']; ?></td> 
		<td><button><a href="del.php?id=<?php echo $rows["id"]; ?>">Added</a></button><button><a href="del23.php?id=<?php echo $rows["id"]; ?>">Reject</a></button></td>
		</tr> 
	<?php 
               } 
          ?> 

	</table> 

	
	
	<div class="toggle-button d-inline-block d-lg-none"><a href="#" class="site-menu-toggle py-5 js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

          </div>
        </div>
	
	
	
	</div>	
		
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-7">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>TRUIP company is a business that provides transportation and freight forwarding services, as well as integrated logistics solutions to companies of all sizes.</p>
              </div>
              <div class="col-md-4 ml-auto">
                <h2 class="footer-heading mb-4">Features</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#"></a></li>
                  <li><a href="#">Terms of Service</a></li>
                  <li><a href="#">Privacy</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div>

            </div>
          </div>
          <div class="col-md-4 ml-auto">

            <div class="mb-5">
              <h2 class="footer-heading mb-4">Subscribe to Newsletter</h2>
              <form action="#" method="post" class="footer-suscribe-form">
                <div class="input-group mb-3">
                  <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                  <div class="input-group-append">
                    <button class="btn btn-primary text-white" type="button" id="button-addon2">Subscribe</button>
                  </div>
                </div>
            </div>


            <h2 class="footer-heading mb-4">Follow Us</h2>
            <a href="#about-section" class="smoothscroll pl-0 pr-3"><span class="icon-facebook"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
            </form>
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
              <p>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                 All rights reserved                 <!-- Link back tomoved. Template is licensed under CC BY 3.0. -->
                </p>
            </div>
          </div>

        </div>
      </div>
    </footer>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>

    <script src="js/main.js"></script>


	
	</body>

</html>