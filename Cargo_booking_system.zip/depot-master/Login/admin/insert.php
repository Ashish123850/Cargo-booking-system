<!DOCTYPE html>
<html>

<head>
	<title>Congratulation Your Profile has been submited sucessfully</title>
</head>

<body>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "loginsystem");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		// Taking all 5 values from the form data(input)
		$first_name = $_REQUEST['c_name'];
		$last_name = $_REQUEST['c_address'];
		$gender = $_REQUEST['c_email'];
		$address = $_REQUEST['c_service'];
		$email = $_REQUEST['c_contact'];
		$details = $_REQUEST['c_details'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO profile VALUES ('$first_name',
			'$last_name','$gender','$address','$email','$details')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully."
				. " Please browse your localhost php my admin"
				. " to view the updated data</h3>";

			echo nl2br("\n$first_name\n $last_name\n "
				. "$gender\n $address\n $email \n $details");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
