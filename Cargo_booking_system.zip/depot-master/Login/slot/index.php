<?php
require '../db.php';
require '../auth_session.php';
?>
       
			
	
	  
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style.css" />
    <title>Slot Booking</title>
  </head>
  <body>
	<?php echo 'Welcome ' . htmlspecialchars($_GET["id"]) . '!'; ?>
    <div class="movie-container">
      <label> Company:</label>
      <select id="movie">
	  
        <option value="220"> </option>
       
      </select>
	  
	  <label> Time : </label>
	  <select>
		<option> select</option>
		<option> 12:30</option>
		<option> 19:15</option>
	  </select>
    </div>

    <ul class="showcase">
      <li>
        <div class="seat"></div>
        <small>Available</small>
      </li>
      <li>
        <div class="seat selected"></div>
        <small>Selected</small>
      </li>
      <li>
        <div class="seat sold"></div>
        <small>Sold</small>
      </li>
    </ul>
    <div class="container">
      

      <div class="row">
        <div class="seat <?php echo "";?>"></div>
        <div class="seat"></div>
        
        <div class="seat"></div>
        <div class="seat"></div>
      </div>

      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        
        <div class="seat"></div>
        <div class="seat"></div>
      </div>
      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        
        <div class="seat "></div>
        <div class="seat "></div>
      </div>
      <div class="row">
        <div class="seat sold"></div>
        <div class="seat <?php echo"";?>"></div>
       
        <div class="seat"></div>
        <div class="seat"></div>
      </div>
      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        
        <div class="seat"></div>
        <div class="seat"></div>
      </div>
      <div class="row">
        <div class="seat"></div>
        <div class="seat"></div>
        
        <div class="seat sold"></div>
        <div class="seat"></div>
      </div>
    </div>

   
	
	<?php
	include('../db.php');
	include('../db_connect.php');
	$id =$_GET['id'];
	$query=mysqli_query($conn,"select * from data where id='$id'");
	while($row=mysqli_fetch_array($query))
	{
	
	?>
	<button> <a href="../practice.php?id=<?php echo $row['id']?>"></button>

	<?php } ?>
	
	    <script src="script.js"></script>
	
			<button> <a href="../slot/book.php?id=">Book now</button>
				
				
			<!--	<a href="../slot/book.php?id=">Book</a> -->
	
	<!--			<center><button> <a href="../slot/pratice.php?id=<?php  $student = $_Get['id']; echo $student['Company_name']?>">Book slot</button> -->
  </body>		<!--		<center><button> <a href="../slot/book.php?id=<?php echo $student['Company_name']?>">Book slot</button>
-->
</html>
