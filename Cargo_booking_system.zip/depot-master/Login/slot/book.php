<!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: white;  
}  
.container {  
    padding: 50px;  
	padding-left:200px;
	padding-right:200px;
  background-color: #9CBED5;
  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  
</head>  
<body>   
<form action="order.php" method="POST">  
  <div class="container">  
  <center>  <h1>  Registeration Form</h1> </center>  
  <hr>  
  <label> Firstname </label>   
<input type="text" name="firstname" placeholder= "Firstname" size="15" required />   
<label> Middlename: </label>   
<input type="text" name="middlename" placeholder="Middlename" size="15" required />   
<label> Lastname: </label>    
<input type="text" name="lastname" placeholder="Lastname" size="15"required />   
<div>

<div> 
Company Name : <input type="name" name="companyname" placeholder="Enter company name" required />
</div>

<div> 

<label>   
Ways :  
</label>   
  
<select>  
<option value="Course">Select</option>  
<option value="BCA">Airways</option>  
<option value="BBA">Roadways</option>  
<option value="B.Tech">Sea ways</option>  
  
</select>  
</div>    
<label>   
From :  
</label>   
  
<select>  
<option value="Course">Select</option>  
<option value="BCA">Mumbai</option>  
<option value="BBA">Kolkata</option>  
<option value="B.Tech">Chennai</option>  
  
</select>  
</div>  
 
 <div>  
<label>   
To :  
</label>   
  
<select>  
<option value="Course">Select</option>  
<option value="BCA">Banglore</option>  
<option value="BBA">Tamil nadu</option>  
<option value="B.Tech">Kanyakumari</option>  
  
</select>  
</div>  
<label>   
Phone :  
</label>  
<input type="text" name="phone" placeholder="phone no." size="10"/ required>   
Delivery Address :  
<textarea cols="80" rows="5" placeholder="Address that order to be delivered" value="address" required>  
</textarea>  
 <label for="email"><b>Email</b></label>  
 <input type="text" placeholder="Enter Email" name="email" required>  
    
<?php
if(isset($_POST['submit']))	 
{ 
header("Location: order.php"); 
} 

?>
    <button type="submit" name="submit" > Book slot</button>    
</form>  
</body>  
</html> 

