<html>

	<head>
	</head>
	
	<body>
	<form action='data.php' method='POST'>
                  <h3>You are registered successfully Please Enter Your Company Details Below.</h3><br/>
                  
				  Company Name : <input type='text' name='c_name' placeholder='Company Name'> <br>
				   Company Details : <input type='text' name='c_details' placeholder='Company Details'> <br>
				    Contact Number : <input type='text' name='c_contact' placeholder='Contact Number of Company'> <br>
				     Ways of service : <input type='text' name='c_way' placeholder='Services Provided'> <br>
					  Pricing range : <input type='text' name='c_price' placeholder='Ex : $200 - $350'> <br>
					   Locations  : <input type='text' name='c_location' placeholder='Locations Of services'> <br>
				  <center><button value='submit'> <a href='data.php'>Submit  </button> </center>
                  <p class='link'>Click here to <a href='login.php'>Login</a></p>
				  </form>
				  </center>
	</body>
</html>