<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>


<html>
	<body>
		
				<?php
	 $con = mysqli_connect("localhost","root","","loginsystem");
  
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$query = "SELECT * FROM provider";
	$query_run = mysqli_query($con,$query);
	$check_faculty = mysqli_num_rows($query_run)>0;
	
	if($check_faculty){
		 
		while($row = mysqli_fetch_assoc($query_run))
		{
			echo "<br>"; ?>
			
				<div class="col-md-4">
			<div class="card">
			<center><?php echo $row["request"];?></center>
				
			</div>
		</div>
			
			<?php 
			
		}
	}
	else{
		echo "No data";
		
	}
	?>
	<body><button> Accepted</button> <button> Rejected</button>

</html>