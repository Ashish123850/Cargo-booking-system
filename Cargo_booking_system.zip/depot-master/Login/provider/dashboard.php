<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>

<!doctype html>
<html lang="en">

  <head>
    <title>TRUIP </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    

    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="../../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="../../css/aos.css">
<!-- MAIN CSS -->
    <link rel="stylesheet" href="../../css/style.css">

   
  </head>
  
<style type="text/css">
  .obj{
	color:red;
	max-width:20%;
	
	
  }
  .obj .company h3{
	  color :red;
	  text-align : center;
	  
	  padding-top:5%
  }
   .obj {
	   color :black;
	   border-style:double;
   }
   .obj .details{
	   text-align:center;
	 
   }
  
	.obj .button{
		border-style:round;
		text-align : center;
		
	}
	.obj .img{
		
		padding-top : 10px;
	}
	.obj .img img{
		width:40%;
		
	}
	button:hover{
		 background-color: black;
  color: white;
  transition: .5s;
  cursor: pointer;
	}
</style>
  
   <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

    

    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>


      
      <header class="site-navbar js-sticky-header site-navbar-target" role="banner">

        <div class="container">
          <div class="row align-items-center position-relative">


            <div class="site-logo">
			  <a href="index.html" class="text-black"><span class="text-primary">TRUIP</a>
			  
            </div>

            <div class="col-9">
              <nav class="site-navigation text-right ml-auto " role="navigation">

                <ul class="site-menu main-menu js-clone-nav ml-auto d-none d-lg-block">
                  <li><a href="#home-section" class="nav-link">Home</a></li>
                  <li><a href="request.php" class="nav-link">Request</a></li>


                  <li>
                    <a href="#about-section" class="nav-link">About Us</a>
                    
                  </li>

                  <li><a href="#why-us-section" class="nav-link">Why Us</a></li>
                  <li><a href="view.php" class="nav-link" >Create Profile</a></li>
                  <li><a href="#contact-section" class="nav-link">Contact</a></li>
				  
					<li><button ><a href="../../chatapp/index.php"> Chat </a></button></li>
				  <li><a href="#contact-section" class="nav-link" ><div class="log">Hii!   <?php echo $_SESSION['username']; ?>  <a href="logout.php">Logout</a></div></a></li>
				     
  </ul>
  	       </nav>

            </div>

            <div class="toggle-button d-inline-block d-lg-none"><a href="#" class="site-menu-toggle py-5 js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

          </div>
        </div>

      </header>  
	  
	  

<div class="contaier py-5">
	<div class="row"> 
	<?php
	 $con = mysqli_connect("localhost","root","","loginsystem");
  
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	$query = "SELECT * FROM data";
	$query_run = mysqli_query($con,$query);
	$check_faculty = mysqli_num_rows($query_run)>0;
	
	if($check_faculty){
		 
		while($row = mysqli_fetch_assoc($query_run))
		{
			echo "<br>"; ?>
			
				<div class="col-md-4">
			<div class="card">
			<center><img src="../<?php echo $row["image"];?>" width="200px" height="200px"></center>
				<div class="card-body">
					
					
					<center><h4 class="card-title"><?php echo $row["Company_name"];?> </h4> </center>
					<center><h6 class="description"><?php echo $row["Details"];?> </h6> </center>
					 <center> <button>Know More... </button> </center>
					
					
					
				</div>
			</div>
		</div>
			
			<?php 
			
		}
	}
	else{
		echo "No data";
		
	}
	?>
		
	</div>
</div>
?>

<br>
	  
	  </div>
	
	  
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-7">
                <h2 class="footer-heading mb-4">About Us</h2>
                <p>TRUIP company is a business that provides transportation and freight forwarding services, as well as integrated logistics solutions to companies of all sizes.</p>
              </div>
              <div class="col-md-4 ml-auto">
                <h2 class="footer-heading mb-4">Features</h2>
                <ul class="list-unstyled">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#"></a></li>
                  <li><a href="#">Terms of Service</a></li>
                  <li><a href="#">Privacy</a></li>
                  <li><a href="#">Contact Us</a></li>
                </ul>
              </div>

            </div>
          </div>
          <div class="col-md-4 ml-auto">

            <div class="mb-5">
              <h2 class="footer-heading mb-4">Subscribe to Newsletter</h2>
              <form action="#" method="post" class="footer-suscribe-form">
                <div class="input-group mb-3">
                  <input type="text" class="form-control border-secondary text-white bg-transparent" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="button-addon2">
                  <div class="input-group-append">
                    <button class="btn btn-primary text-white" type="button" id="button-addon2">Subscribe</button>
                  </div>
                </div>
            </div>


            <h2 class="footer-heading mb-4">Follow Us</h2>
            <a href="#about-section" class="smoothscroll pl-0 pr-3"><span class="icon-facebook"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-twitter"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-instagram"></span></a>
            <a href="#" class="pl-3 pr-3"><span class="icon-linkedin"></span></a>
            </form>
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
              <p>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                 All rights reserved                 <!-- Link back tomoved. Template is licensed under CC BY 3.0. -->
                </p>
            </div>
          </div>

        </div>
      </div>
    </footer>

    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/aos.js"></script>

    <script src="js/main.js"></script>


  </body>

  </html>