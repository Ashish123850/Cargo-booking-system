<?php

$host = "localhost";
$username = "root";
$password = "";


if(isset($_POST['submit'])){
		$c_name = $_POST['c_name'];
		$c_details = $_POST['c_details'];
		$c_contact = $_POST['c_contact'];
		$c_way = $_POST['c_way'];
		$c_price = $_POST['c_price'];
		$c_location = $_POST['c_location'];
		$sql = "INSERT INTO data (c_name, c_details, c_contact,c_way,c_price,c_location) VALUES ('$c_name', '$c_details', '$c_contact',$c_way,$c_price,$c_location)";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Member added successfully';
		}
		///////////////

		//use for MySQLi Procedural
		// if(mysqli_query($conn, $sql)){
		// 	$_SESSION['success'] = 'Member added successfully';
		// }
		//////////////
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
?>