<?php 
require_once("connection.php");
    $query = " select * from query ";
    $result = mysqli_query($con,$query);
?> 
<html>
	
	<head>
	 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    

    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/jquery.fancybox.min.css">
    <link rel="stylesheet" href="../../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="../../css/aos.css">
<!-- MAIN CSS -->
    <link rel="stylesheet" href="../../css/style.css">

   
	</head>
	
	<body>
	
		
			
			<table align="center" border="1px" style="width:600px; line-height:40px;"> 
	<tr> 
		<th colspan="4"><h2><center> Company Details </center></h2></th> 
		</tr> 
			  <th> First Name</th> 
			  <th> Last Name </th> 
			  <th>  Email </th> 
			  <th> query  </th> 
			  
			  <th>Actions </th> 
			  
			  
		</tr> 
		
		<?php while($rows=mysqli_fetch_assoc($result)) 
		{ 
		?> 
		<tr> 
		<td><?php echo $rows['fname']; ?></td> 
		<td><?php echo $rows['lname']; ?></td> 
		<td><?php echo $rows['email']; ?></td> 
		<td><?php echo $rows['query']; ?></td> 
		 
		<td><button><a href="del.php?id=<?php echo $rows["id"]; ?>">Added</a></button><button><a href="del23.php?id=<?php echo $rows["id"]; ?>">Reject</a></button></td>
		</tr> 
	<?php 
               } 
          ?> 

	</table> 

	
	</body>