<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<body><input type="checkbox" id="click">
  <label for="click">
    <i class="fab fa-facebook-messenger"></i>
    <i class="fas fa-times"></i>
  
</label>
  <div class="wrapper3">
    <section class="chat-area">
      <header>
        <?php 
          $user_id = mysqli_real_escape_string($conn, $_GET['user_id']);
          $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$user_id}");
          if(mysqli_num_rows($sql) > 0){
            $row = mysqli_fetch_assoc($sql);
          }else{
            header("location: index.php");
          }
        ?>
   <a href="users.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
           <div class="details">
          <span><?php echo $row['fname']. " " . $row['lname'] ?></span>
          
        </div>
        <a onclick="checker()" href="php/logout.php?logout_id=<?php echo $row['unique_id']; ?>" class="logout">Logout</a>
      </header>
      <div class="chat-box">

      </div>
      <form action="#" class="typing-area">
        <input type="text" class="incoming_id" name="incoming_id" value="<?php echo $user_id; ?>" hidden>
        <input type="text" name="message" class="input-field" placeholder="Type a message here..." autocomplete="off">
        <button><i class="fab fa-telegram-plane"></i></button>
      </form>
        
    </section>
  </div>

  <script src="javascript/chat.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script>
            function checker(){
              var result = confirm('Are you sure');
              if(result == false){
                event.preventDefault();
              }
            }
            </script>
</body>
</html>
